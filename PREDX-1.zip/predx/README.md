# PREDX ChatGPT AI (Android, Kotlin + Jetpack Compose)

Native Android app: 5 bottom tabs (Home, Chat, Apps, Tools, Settings), animated AI orb,
streaming AI chat, voice in/out, app launching, WhatsApp/YouTube helpers, voice notes,
optional AccessibilityService. Real AI API (OpenAI-compatible) — koi fake jawab nahi.

## Zaroori sach (limits)
- **Ye zip me sirf source code hai. APK is zip me nahi hai.** APK aapko neeche ke steps se banana hai.
- Code ka aakhri Gradle build maine nahi chalaya (mere environment me Android SDK/Gradle nahi tha).
  Pehli build par chhoti compile errors aa sakti hain — error text bhejein, theek kar dunga.
- Termux me APK banana **experimental** hai (docs/TERMUX.md). Sab se bharosemand tareeqa: GitHub Actions (free).
- WhatsApp: message prefill hota hai, **Send aap khud dabate hain**. Auto-send / private chats ka access nahi.
- YouTube: search/open + AI se title/description/comment draft. Publish ya comment post **shamil nahi** (YouTube Data API + OAuth chahiye).
- Installed apps ki list `queries` + launcher intent se aati hai (QUERY_ALL_PACKAGES nahi). Kuch apps Android 11+ me chhupi reh sakti hain.
- Recording sirf app khuli ho tab, mic dabane par. Call recording / dusri app ki audio: nahi.
- Accessibility: optional; sirf Back, Home, text-button tap; aap hi Settings me enable karte hain. Lock screen/passwords/permission dialogs bypass nahi.
- Urdu/Hindi bolna-sunna device ki speech/TTS voices par depend karta hai.
- Chat history app-private storage me plain JSON hai (cloud backup band). API key Keystore-encrypted hai.
- Image analysis sirf vision model + Settings me "Vision support" on hone par.

## Folder structure
```
predx/
├── settings.gradle.kts, build.gradle.kts, gradle.properties
├── app/
│   ├── build.gradle.kts            (Compose BOM 2024.09, AGP 8.5.2, Kotlin 1.9.24, minSdk 26, target 34)
│   └── src/
│       ├── main/AndroidManifest.xml
│       ├── main/res/ (theme, icon, network_security_config, accessibility config)
│       ├── main/java/com/predx/ai/
│       │   ├── MainActivity.kt
│       │   ├── ui/        Theme, Orb, App(nav), Home/Chat/Apps/Tools/Settings screens, MainViewModel
│       │   ├── ai/        AiClient (streaming SSE)
│       │   ├── data/      Prefs (encrypted key), ChatStore (JSON)
│       │   ├── voice/     VoiceController (STT+TTS), VoiceRecorder
│       │   ├── device/    DeviceActions (intents), Commands (voice command parser), FileInput
│       │   └── accessibility/PredxAccessibilityService.kt
│       └── test/          CommandParserTest, FormatTest (JUnit)
├── backend/               optional proxy (Python stdlib): server.py, test_server.py, .env.example
├── docs/TERMUX.md         Termux guide
└── .github/workflows/build-apk.yml
```

## Architecture choice
Native Kotlin: intents, SpeechRecognizer/TTS, MediaRecorder, Keystore aur AccessibilityService sirf native Android se milte hain.
Termux me chalne wala web server dusri apps ko control **nahi** kar sakta.
`backend/` optional hai: asli API key server par rehti hai, app ko sirf token milta hai.
Backend FastAPI ke bajaye Python **stdlib** me likha hai, taake Termux par pydantic/Rust compile na karna pade.

## Sab se aasan route: GitHub se APK
1. github.com par naya (private) repo banayein.
2. Zip extract karke is folder ko repo me push karein (Termux me: `pkg install git`, phir `git init && git add . && git commit -m init && git remote add origin <url> && git push -u origin main`).
3. Repo → **Actions** tab → "Build APK" → run complete hone par **Artifacts → PREDX-debug-apk** download karein.
4. APK install karein (Unknown sources allow). Ye debug-signed APK hai.

## App setup (pehli baar)
Settings → AI provider:
- Direct: endpoint `https://api.openai.com/v1`, model, aur apni API key (encrypted save hoti hai).
- Ya proxy ke saath: endpoint `http://127.0.0.1:8000/v1`, key = `PREDX_TOKEN` (docs/TERMUX.md).
"Connection test" dabayein.

## Tests
```
cd backend && python3 -m unittest -v          # proxy tests
gradle :app:testDebugUnitTest                 # Kotlin unit tests (Android SDK chahiye)
```
Instrumented (on-device) tests is version me shamil nahi; manual checklist: mic permission dialog, Start/Pause/Stop, TTS Urdu/English, app open, recorder pause/resume, history delete.

## Permissions
INTERNET, ACCESS_NETWORK_STATE (offline banner), RECORD_AUDIO (sirf mic dabane par). Baqi sab intents hain, extra permission nahi.
