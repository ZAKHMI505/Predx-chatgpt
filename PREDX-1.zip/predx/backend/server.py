#!/usr/bin/env python3
"""PREDX proxy: Android app -> (ye server) -> AI provider.

Maqsad: asli API key phone/APK me na rakhi jaye. App ko sirf PREDX_TOKEN milta hai.
Sirf Python standard library — Termux par koi compile/pip install nahi chahiye.

Endpoints:
  GET  /health                  -> {"ok": true}
  POST /v1/chat/completions     -> upstream /chat/completions par forward (streaming SSE support)
"""
import hmac
import json
import os
import sys
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MAX_BODY = 8 * 1024 * 1024  # base64 images ke liye


def load_env(path=".env"):
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


class Handler(BaseHTTPRequestHandler):
    server_version = "PredxProxy/1.0"
    protocol_version = "HTTP/1.0"  # connection band hone se stream khatam: chunked encoding ki zaroorat nahi

    def log_message(self, fmt, *args):
        sys.stderr.write("[predx] %s - %s\n" % (self.address_string(), fmt % args))

    def _json(self, code, obj):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _authorized(self):
        token = os.environ.get("PREDX_TOKEN", "")
        if not token:
            return False
        got = self.headers.get("Authorization", "")
        return hmac.compare_digest(got.encode(), ("Bearer " + token).encode())

    def do_GET(self):
        if self.path == "/health":
            return self._json(200, {"ok": True})
        self._json(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/v1/chat/completions":
            return self._json(404, {"error": "not found"})
        if not self._authorized():
            return self._json(401, {"error": "unauthorized"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0:
            return self._json(400, {"error": "empty body"})
        if length > MAX_BODY:
            return self._json(413, {"error": "body too large"})
        raw = self.rfile.read(length)
        try:
            payload = json.loads(raw)
            if not isinstance(payload, dict) or not isinstance(payload.get("messages"), list):
                raise ValueError("messages missing")
        except ValueError:
            return self._json(400, {"error": "invalid JSON body (messages list chahiye)"})

        upstream_key = os.environ.get("UPSTREAM_API_KEY", "")
        if not upstream_key:
            return self._json(500, {"error": "server par UPSTREAM_API_KEY set nahi"})
        base = os.environ.get("UPSTREAM_BASE_URL", "https://api.openai.com/v1").rstrip("/")
        allowed = [m.strip() for m in os.environ.get("ALLOWED_MODELS", "").split(",") if m.strip()]
        if allowed and payload.get("model") not in allowed:
            return self._json(400, {"error": "model allowed list me nahi"})

        req = urllib.request.Request(
            base + "/chat/completions",
            data=json.dumps(payload).encode(),
            headers={"Authorization": "Bearer " + upstream_key, "Content-Type": "application/json",
                     "Accept": "text/event-stream" if payload.get("stream") else "application/json"},
            method="POST",
        )
        try:
            resp = urllib.request.urlopen(req, timeout=120)
        except urllib.error.HTTPError as e:
            body = e.read()
            self.send_response(e.code)
            self.send_header("Content-Type", e.headers.get("Content-Type", "application/json"))
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            return self._json(502, {"error": "upstream tak nahi pahunch saka: %s" % e})

        with resp:
            self.send_response(200)
            self.send_header("Content-Type", resp.headers.get("Content-Type", "text/event-stream"))
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            try:
                for line in resp:  # line-by-line: SSE foran forward hota hai
                    self.wfile.write(line)
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError):
                pass  # app ne Stop dabaya


def main():
    load_env()
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8000"))
    token = os.environ.get("PREDX_TOKEN", "")
    if len(token) < 16:
        sys.exit("PREDX_TOKEN kam az kam 16 characters ka set karein (.env dekhein).")
    if not os.environ.get("UPSTREAM_API_KEY"):
        sys.exit("UPSTREAM_API_KEY set nahi (.env dekhein).")
    print("PREDX proxy http://%s:%d par chal raha hai (Ctrl+C se band)" % (host, port))
    ThreadingHTTPServer((host, port), Handler).serve_forever()


if __name__ == "__main__":
    main()
