import json
import os
import threading
import unittest
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import server


class FakeUpstream(BaseHTTPRequestHandler):
    seen_auth = None

    def log_message(self, *a):
        pass

    def do_POST(self):
        FakeUpstream.seen_auth = self.headers.get("Authorization")
        n = int(self.headers["Content-Length"])
        body = json.loads(self.rfile.read(n))
        if body.get("model") == "boom":
            self.send_response(429)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"error":"rate"}')
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.end_headers()
        for tok in ("Sal", "am"):
            self.wfile.write(('data: {"choices":[{"delta":{"content":"%s"}}]}\n\n' % tok).encode())
            self.wfile.flush()
        self.wfile.write(b"data: [DONE]\n\n")


def start(handler):
    srv = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


class ProxyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.up = start(FakeUpstream)
        cls.px = start(server.Handler)
        cls.base = "http://127.0.0.1:%d" % cls.px.server_address[1]
        os.environ["PREDX_TOKEN"] = "t" * 24
        os.environ["UPSTREAM_API_KEY"] = "real-secret"
        os.environ["UPSTREAM_BASE_URL"] = "http://127.0.0.1:%d" % cls.up.server_address[1]
        os.environ["ALLOWED_MODELS"] = ""

    @classmethod
    def tearDownClass(cls):
        cls.up.shutdown()
        cls.px.shutdown()

    def post(self, body, token="t" * 24, raw=None):
        data = raw if raw is not None else json.dumps(body).encode()
        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = "Bearer " + token
        req = urllib.request.Request(self.base + "/v1/chat/completions", data=data, headers=headers, method="POST")
        try:
            r = urllib.request.urlopen(req)
            return r.status, r.read().decode()
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode()

    def test_health(self):
        r = urllib.request.urlopen(self.base + "/health")
        self.assertEqual(json.loads(r.read()), {"ok": True})

    def test_requires_token(self):
        self.assertEqual(self.post({"messages": []}, token=None)[0], 401)

    def test_wrong_token(self):
        self.assertEqual(self.post({"messages": []}, token="x" * 24)[0], 401)

    def test_bad_json(self):
        self.assertEqual(self.post(None, raw=b"not json")[0], 400)

    def test_streams_and_swaps_key(self):
        code, text = self.post({"model": "m", "stream": True, "messages": [{"role": "user", "content": "hi"}]})
        self.assertEqual(code, 200)
        self.assertIn('"content":"Sal"', text)
        self.assertIn("[DONE]", text)
        self.assertEqual(FakeUpstream.seen_auth, "Bearer real-secret")  # client token upstream nahi jata

    def test_upstream_error_forwarded(self):
        code, text = self.post({"model": "boom", "messages": [{"role": "user", "content": "x"}]})
        self.assertEqual(code, 429)

    def test_missing_upstream_key(self):
        old = os.environ["UPSTREAM_API_KEY"]
        os.environ["UPSTREAM_API_KEY"] = ""
        try:
            self.assertEqual(self.post({"messages": [{"role": "user", "content": "x"}]})[0], 500)
        finally:
            os.environ["UPSTREAM_API_KEY"] = old

    def test_model_allowlist(self):
        os.environ["ALLOWED_MODELS"] = "good"
        try:
            self.assertEqual(self.post({"model": "bad", "messages": []})[0], 400)
        finally:
            os.environ["ALLOWED_MODELS"] = ""


if __name__ == "__main__":
    unittest.main()
