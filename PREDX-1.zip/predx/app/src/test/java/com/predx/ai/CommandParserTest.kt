package com.predx.ai

import com.predx.ai.data.AppInfo
import com.predx.ai.device.Cmd
import com.predx.ai.device.CommandParser
import com.predx.ai.ui.splitCode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {
    private val apps = listOf(
        AppInfo("YouTube", "com.google.android.youtube"),
        AppInfo("WhatsApp", "com.whatsapp"),
        AppInfo("Chrome", "com.android.chrome")
    )

    @Test fun opensInstalledApp() = assertEquals(Cmd.OpenApp(apps[1]), CommandParser.parse("open whatsapp", apps))
    @Test fun urduStyleSuffix() = assertEquals(Cmd.OpenApp(apps[2]), CommandParser.parse("chrome kholo", apps))
    @Test fun youtubeSearch() = assertEquals(Cmd.YouTubeSearch("cats"), CommandParser.parse("search cats on youtube", apps))
    @Test fun youtubeFallbackUrl() = assertEquals(Cmd.OpenUrl("https://www.youtube.com"), CommandParser.parse("open youtube", emptyList()))
    @Test fun wifiSettings() = assertTrue(CommandParser.parse("open wifi", apps) is Cmd.OpenSettings)
    @Test fun normalQuestionGoesToAi() = assertNull(CommandParser.parse("what is the capital of france", apps))
    @Test fun unknownAppGoesToAi() = assertNull(CommandParser.parse("open nonexistentapp", apps))
}

class FormatTest {
    @Test fun splitsCodeFences() {
        val s = splitCode("Hello\n```kotlin\nval x = 1\n```\nBye")
        assertEquals(3, s.size)
        assertEquals("val x = 1", s[1].text)
        assertTrue(s[1].isCode)
        assertEquals(false, s[0].isCode)
    }
    @Test fun unclosedFenceTreatedAsCode() {
        val s = splitCode("Intro ```python\nprint(1)")
        assertTrue(s.last().isCode)
    }
}
