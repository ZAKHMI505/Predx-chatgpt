package com.predx.ai.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Chat history app-private storage me JSON file ki shakal me (allowBackup=false). */
class ChatStore(ctx: Context) {
    private val file = File(ctx.filesDir, "chats.json")

    fun load(): List<Conversation> = try {
        if (!file.exists()) emptyList() else {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val m = o.getJSONArray("messages")
                Conversation(
                    o.getString("id"), o.getString("title"),
                    (0 until m.length()).map { j ->
                        val mo = m.getJSONObject(j)
                        Message(mo.getString("role"), mo.getString("content"))
                    },
                    o.optLong("updatedAt")
                )
            }
        }
    } catch (e: Exception) { emptyList() }

    fun save(list: List<Conversation>) {
        try {
            val arr = JSONArray()
            list.forEach { c ->
                val msgs = JSONArray()
                c.messages.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
                arr.put(JSONObject().put("id", c.id).put("title", c.title).put("updatedAt", c.updatedAt).put("messages", msgs))
            }
            file.writeText(arr.toString())
        } catch (e: Exception) { android.util.Log.e("ChatStore", "save failed", e) }
    }

    fun clear() { file.delete() }
}
