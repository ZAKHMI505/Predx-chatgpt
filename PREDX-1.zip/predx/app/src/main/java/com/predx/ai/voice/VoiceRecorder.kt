package com.predx.ai.voice

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Voice notes: start / pause / resume / stop. Files app-private storage me. */
class VoiceRecorder(private val ctx: Context) {
    private var rec: MediaRecorder? = null
    val isActive: Boolean get() = rec != null
    private val dir: File get() = File(ctx.filesDir, "recordings").also { it.mkdirs() }

    fun start(): Boolean {
        if (rec != null) return false
        return try {
            val f = File(dir, "note_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".m4a")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(96_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(f.absolutePath)
            r.prepare()
            r.start()
            rec = r
            true
        } catch (e: Exception) {
            rec?.release(); rec = null
            false
        }
    }

    fun pause() { try { rec?.pause() } catch (e: Exception) { } }
    fun resume() { try { rec?.resume() } catch (e: Exception) { } }

    fun stop() {
        try { rec?.stop() } catch (e: RuntimeException) { /* bohot chhoti recording */ }
        rec?.release()
        rec = null
    }

    fun list(): List<File> =
        dir.listFiles()?.filter { it.extension == "m4a" }?.sortedByDescending { it.lastModified() } ?: emptyList()
}
