package com.predx.ai.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

enum class OrbState { Idle, Listening, Processing, Speaking, Error }

@Composable
fun Orb(state: OrbState, modifier: Modifier = Modifier, orbSize: Dp = 220.dp) {
    val dur = when (state) {
        OrbState.Idle -> 3200
        OrbState.Listening -> 1100
        OrbState.Processing -> 650
        OrbState.Speaking -> 800
        OrbState.Error -> 1600
    }
    val amp = when (state) {
        OrbState.Idle -> 0.04f
        OrbState.Listening -> 0.14f
        OrbState.Processing -> 0.08f
        OrbState.Speaking -> 0.18f
        OrbState.Error -> 0.05f
    }
    val base = if (state == OrbState.Error) Color(0xFFFF5C5C) else Color(0xFF10B981)
    val t = rememberInfiniteTransition(label = "orb")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(dur, easing = LinearEasing), RepeatMode.Reverse), label = "pulse")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "spin")

    Canvas(modifier.size(orbSize)) {
        val r = this.size.minDimension / 2f
        val s = 1f + amp * p
        // glow
        drawCircle(Brush.radialGradient(listOf(base.copy(0.38f), Color.Transparent), center, r), r * s)
        // core
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White.copy(0.92f), base, Color(0xFF064E3B)),
                center = Offset(center.x - r * 0.18f, center.y - r * 0.25f),
                radius = r * 0.75f
            ),
            r * 0.55f * s
        )
        // ring
        rotate(spin) {
            drawArc(
                base.copy(0.75f), 0f, 100f, false,
                topLeft = Offset(center.x - r * 0.72f, center.y - r * 0.72f),
                size = Size(r * 1.44f, r * 1.44f),
                style = Stroke(width = 6f, cap = StrokeCap.Round)
            )
        }
    }
}
