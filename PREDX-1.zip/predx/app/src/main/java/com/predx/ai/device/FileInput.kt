package com.predx.ai.device

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import java.io.ByteArrayOutputStream

data class Loaded(val name: String, val value: String?, val error: String?)

/** Uploads ki validation: type aur size check, phir hi parhna. */
object FileInput {
    private const val MAX_TEXT = 1_000_000L
    private const val MAX_IMG = 10_000_000L

    private fun info(ctx: Context, uri: Uri): Pair<String, Long> {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                return Pair(
                    if (ni >= 0) c.getString(ni) ?: "file" else "file",
                    if (si >= 0 && !c.isNull(si)) c.getLong(si) else -1L
                )
            }
        }
        return Pair("file", -1L)
    }

    fun readText(ctx: Context, uri: Uri): Loaded {
        val (name, size) = info(ctx, uri)
        val mime = ctx.contentResolver.getType(uri).orEmpty()
        val ok = mime.startsWith("text/") || mime == "application/json" || mime == "application/xml"
        if (!ok) return Loaded(name, null, "Sirf text, CSV, JSON ya XML files supported hain ($mime).")
        if (size > MAX_TEXT) return Loaded(name, null, "File 1 MB se badi hai.")
        return try {
            val txt = ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use {
                val buf = CharArray(20_000)
                val n = it.read(buf)
                if (n <= 0) "" else String(buf, 0, n)
            }
            Loaded(name, txt, null)
        } catch (e: Exception) { Loaded(name, null, "File parh nahi saka: ${e.message}") }
    }

    fun readImage(ctx: Context, uri: Uri): Loaded {
        val (name, size) = info(ctx, uri)
        val mime = ctx.contentResolver.getType(uri).orEmpty()
        if (!mime.startsWith("image/")) return Loaded(name, null, "Ye image file nahi hai ($mime).")
        if (size > MAX_IMG) return Loaded(name, null, "Image 10 MB se badi hai.")
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            while (opts.outWidth / sample > 1024 || opts.outHeight / sample > 1024) sample *= 2
            val bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return Loaded(name, null, "Image decode nahi hui.")
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
            Loaded(name, "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP), null)
        } catch (e: Exception) { Loaded(name, null, "Image parh nahi saka: ${e.message}") }
    }
}
