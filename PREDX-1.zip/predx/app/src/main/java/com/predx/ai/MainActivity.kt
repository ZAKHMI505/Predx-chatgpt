package com.predx.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.predx.ai.ui.MainViewModel
import com.predx.ai.ui.PredxApp
import com.predx.ai.ui.PredxTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { PredxTheme(vm.theme) { PredxApp(vm) } }
    }

    override fun onResume() {
        super.onResume()
        vm.resumeTick++   // permission / accessibility status dobara check karwata hai
    }
}
