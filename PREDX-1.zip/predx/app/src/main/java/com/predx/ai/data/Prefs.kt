package com.predx.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/** Settings. API key sirf EncryptedSharedPreferences (Android Keystore) me save hoti hai. */
class Prefs(context: Context) {
    private val sp: SharedPreferences = context.getSharedPreferences("predx_prefs", Context.MODE_PRIVATE)

    private val secure: SharedPreferences? = try {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "predx_secure", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        null // secure storage unavailable: key save nahi hogi (plain text me kabhi nahi)
    }

    val secureAvailable: Boolean get() = secure != null

    var apiKey: String
        get() = secure?.getString("api_key", "") ?: ""
        set(v) { secure?.edit()?.putString("api_key", v.trim())?.apply() }

    private fun s(k: String, d: String) = sp.getString(k, d) ?: d
    private fun put(k: String, v: String) = sp.edit().putString(k, v).apply()

    var baseUrl: String
        get() = s("base_url", "https://api.openai.com/v1")
        set(v) = put("base_url", v.trim())
    var model: String
        get() = s("model", "gpt-4o-mini")
        set(v) = put("model", v.trim())
    var vision: Boolean
        get() = sp.getBoolean("vision", false)
        set(v) = sp.edit().putBoolean("vision", v).apply()
    var assistantName: String
        get() = s("assistant_name", "PREDX")
        set(v) = put("assistant_name", v.trim())
    var personality: String
        get() = s("personality", "Friendly")
        set(v) = put("personality", v)
    var customInstructions: String
        get() = s("custom", "")
        set(v) = put("custom", v)
    var language: String
        get() = s("lang", "en-US")
        set(v) = put("lang", v)
    var voiceName: String
        get() = s("voice", "")
        set(v) = put("voice", v)
    var speechRate: Float
        get() = sp.getFloat("rate", 1f)
        set(v) = sp.edit().putFloat("rate", v).apply()
    var volume: Float
        get() = sp.getFloat("volume", 1f)
        set(v) = sp.edit().putFloat("volume", v).apply()
    /** 0 = system, 1 = light, 2 = dark */
    var theme: Int
        get() = sp.getInt("theme", 2)
        set(v) = sp.edit().putInt("theme", v).apply()
    var saveHistory: Boolean
        get() = sp.getBoolean("save_history", true)
        set(v) = sp.edit().putBoolean("save_history", v).apply()

    fun shortcuts(): List<Shortcut> = try {
        val a = JSONArray(s("shortcuts", "[]"))
        (0 until a.length()).map { val o = a.getJSONObject(it); Shortcut(o.getString("l"), o.getString("t")) }
    } catch (e: Exception) { emptyList() }

    fun saveShortcuts(list: List<Shortcut>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("l", it.label).put("t", it.target)) }
        put("shortcuts", a.toString())
    }

    fun notes(): List<String> = try {
        val a = JSONArray(s("notes", "[]"))
        (0 until a.length()).map { a.getString(it) }
    } catch (e: Exception) { emptyList() }

    fun saveNotes(list: List<String>) {
        val a = JSONArray()
        list.forEach { a.put(it) }
        put("notes", a.toString())
    }
}
