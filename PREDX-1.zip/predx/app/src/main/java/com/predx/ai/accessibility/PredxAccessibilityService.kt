package com.predx.ai.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import androidx.compose.runtime.mutableStateOf

/**
 * OPTIONAL. User ko Android Settings → Accessibility me khud enable karna padta hai.
 * Ye sirf wahi actions karta hai jo app me user ne confirm kiye (Back, Home, text wale button par tap).
 * Passwords/private content na padhta hai na bhejta hai; lock screen ya permission dialogs ko bypass nahi karta.
 */
class PredxAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: PredxAccessibilityService? = null
        val enabled = mutableStateOf(false)

        fun isEnabledInSettings(ctx: Context): Boolean {
            val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            return s.contains(ctx.packageName + "/" + PredxAccessibilityService::class.java.name)
        }
    }

    override fun onServiceConnected() {
        instance = this
        enabled.value = true
        Toast.makeText(this, "PREDX automation ON", Toast.LENGTH_SHORT).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* events process nahi karte */ }
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        enabled.value = false
        return super.onUnbind(intent)
    }

    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK).also { toast("Automation: Back") }
    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME).also { toast("Automation: Home") }

    fun clickText(text: String): Boolean {
        toast("Automation: \"$text\" par tap")
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(text)) {
            var cur: AccessibilityNodeInfo? = n
            while (cur != null && !cur.isClickable) cur = cur.parent
            if (cur != null && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
