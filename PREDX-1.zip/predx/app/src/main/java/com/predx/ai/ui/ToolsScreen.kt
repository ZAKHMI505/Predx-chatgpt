package com.predx.ai.ui

import android.media.MediaPlayer
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.predx.ai.accessibility.PredxAccessibilityService
import com.predx.ai.device.DeviceActions
import com.predx.ai.device.FileInput
import com.predx.ai.voice.VoiceRecorder
import kotlinx.coroutines.delay
import java.io.File

private class PlayerHolder { var mp: MediaPlayer? = null }

@Composable
fun ToolsScreen(vm: MainViewModel, requestMic: (() -> Unit) -> Unit, goHome: () -> Unit) {
    val ctx = LocalContext.current
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    var input by remember { mutableStateOf("") }
    var fileName by remember { mutableStateOf("") }
    var fileText by remember { mutableStateOf("") }
    var imageData by remember { mutableStateOf<String?>(null) }
    var fileMsg by remember { mutableStateOf("") }
    var noteText by remember { mutableStateOf("") }
    var remTitle by remember { mutableStateOf("") }
    var remMins by remember { mutableStateOf("10") }
    var waPhone by remember { mutableStateOf("") }
    var waMsg by remember { mutableStateOf("") }
    var waAsk by remember { mutableStateOf("") }
    var ytQuery by remember { mutableStateOf("") }
    var ytTopic by remember { mutableStateOf("") }
    var clickLabel by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }
    var info by remember { mutableStateOf<String?>(null) }

    // ---- recorder state ----
    val recorder = remember { VoiceRecorder(ctx) }
    var recState by remember { mutableIntStateOf(0) } // 0 idle, 1 recording, 2 paused
    var elapsed by remember { mutableIntStateOf(0) }
    var files by remember { mutableStateOf(recorder.list()) }
    var playing by remember { mutableStateOf<String?>(null) }
    val player = remember { PlayerHolder() }
    DisposableEffect(Unit) {
        onDispose { if (recorder.isActive) recorder.stop(); player.mp?.release() } // tab badalne par recording ruk jati hai
    }
    LaunchedEffect(recState) {
        if (recState == 1) while (true) { delay(1000); elapsed++ }
    }

    val textPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val r = FileInput.readText(ctx, uri)
            fileName = r.name; fileText = r.value.orEmpty(); fileMsg = r.error ?: "✅ ${r.name} load ho gayi (pehle 20,000 characters)"
        }
    }
    val imgPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val r = FileInput.readImage(ctx, uri)
            fileName = r.name; imageData = r.value; fileMsg = r.error ?: "✅ ${r.name} image load ho gayi"
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Tools", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        info?.let { Banner(it) { info = null } }

        Section("🎧 Voice conversation") {
            Text("Home ki tarah mic se baat karein; jawab bol kar sunaya jata hai.", style = MaterialTheme.typography.bodySmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { requestMic { vm.startListening(); goHome() } }) { Text("🎤 Voice chat shuru") }
                OutlinedButton(onClick = { vm.speak(input.ifBlank { "Hello, I am your PREDX assistant." }) }) { Text("🔊 Text sunao") }
            }
        }

        Section("✍️ Text tools") {
            OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), minLines = 3, placeholder = { Text("Text ya code yahan paste karein") })
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { DeviceActions.readClipboard(ctx)?.let { input = it } ?: toast("Clipboard khali hai") }) { Text("📋 Paste") }
                Button(enabled = input.isNotBlank(), onClick = { vm.runTool("Summarize the following text concisely, in the same language:\n\n$input") }) { Text("Summarize") }
                Button(enabled = input.isNotBlank(), onClick = { vm.runTool("Translate the following text to Urdu (Urdu script). Output only the translation:\n\n$input") }) { Text("→ Urdu") }
                Button(enabled = input.isNotBlank(), onClick = { vm.runTool("Translate the following text to English. Output only the translation:\n\n$input") }) { Text("→ English") }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = input.isNotBlank(), onClick = { vm.runTool("Explain what this code does, step by step:\n\n$input") }) { Text("Explain code") }
                Button(enabled = input.isNotBlank(), onClick = { vm.runTool("Find bugs in this code and give a corrected version:\n\n$input") }) { Text("Fix code") }
            }
            if (vm.toolBusy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            if (vm.toolOut.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                MessageText(vm.toolOut)
                Row {
                    TextButton(onClick = { DeviceActions.copy(ctx, vm.toolOut); toast("Copy ho gaya") }) { Text("Copy") }
                    TextButton(onClick = { vm.speak(vm.toolOut) }) { Text("🔊 Sunao") }
                    if (vm.toolBusy) TextButton(onClick = { vm.stopAll() }) { Text("⏹ Stop") }
                }
            }
        }

        Section("📄 File & image analysis") {
            Text("Text/CSV/JSON files (max 1 MB) aur images (vision model + Settings me Vision support on).", style = MaterialTheme.typography.bodySmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { textPicker.launch(arrayOf("text/*", "application/json", "application/xml")) }) { Text("Text file chunein") }
                OutlinedButton(onClick = { imgPicker.launch(arrayOf("image/*")) }) { Text("Image chunein") }
            }
            if (fileMsg.isNotBlank()) Text(fileMsg, style = MaterialTheme.typography.bodySmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = fileText.isNotBlank(), onClick = {
                    vm.runTool("File \"$fileName\". Task: ${input.ifBlank { "Summarize and list key points." }}\n\n---\n$fileText")
                }) { Text("File analyze") }
                Button(enabled = imageData != null, onClick = {
                    vm.runTool(input.ifBlank { "Describe this image." }, imageData)
                }) { Text("Image analyze") }
            }
            Text("(Sawal/hukm upar Text tools ke box me likhein; jawab wahin dikhega.)", style = MaterialTheme.typography.bodySmall)
        }

        Section("📝 Notes & ⏰ reminders") {
            OutlinedTextField(noteText, { noteText = it }, Modifier.fillMaxWidth(), placeholder = { Text("Naya note") })
            Button(enabled = noteText.isNotBlank(), onClick = { vm.addNote(noteText); noteText = "" }) { Text("Note save karein") }
            vm.notes.toList().forEachIndexed { i, n ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("• $n", Modifier.weight(1f))
                    TextButton(onClick = { vm.removeNote(i) }) { Text("Delete") }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(remTitle, { remTitle = it }, Modifier.weight(1f), placeholder = { Text("Reminder") }, singleLine = true)
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(remMins, { remMins = it.filter(Char::isDigit).take(4) }, Modifier.width(90.dp), label = { Text("min") }, singleLine = true)
            }
            Button(enabled = remTitle.isNotBlank(), onClick = {
                info = DeviceActions.reminder(ctx, remTitle.trim(), remMins.toIntOrNull() ?: 10)
            }) { Text("Calendar me reminder banayein") }
            Text("Calendar app khulta hai; aap Save dabayen to hi reminder banta hai.", style = MaterialTheme.typography.bodySmall)
        }

        Section("💬 WhatsApp (draft → aap review → aap send)") {
            OutlinedTextField(waPhone, { waPhone = it }, Modifier.fillMaxWidth(), label = { Text("Number (country code ke saath, optional)") }, singleLine = true)
            OutlinedTextField(waAsk, { waAsk = it }, Modifier.fillMaxWidth(), label = { Text("AI ko batayein kya likhna hai (optional)") })
            Button(enabled = waAsk.isNotBlank() && !vm.toolBusy, onClick = {
                vm.runTool("Write a short, polite WhatsApp message. Output only the message text. Request: $waAsk") { waMsg = it.trim() }
            }) { Text("✨ AI se draft") }
            OutlinedTextField(waMsg, { waMsg = it }, Modifier.fillMaxWidth(), minLines = 2, label = { Text("Message (edit kar sakte hain)") })
            Button(enabled = waMsg.isNotBlank(), onClick = {
                confirm = "WhatsApp is message ke saath khulega. Send aap khud dabayenge — PREDX khud nahi bhejta." to {
                    info = DeviceActions.whatsApp(ctx, waPhone, waMsg)
                }
            }) { Text("WhatsApp me kholein") }
        }

        Section("▶ YouTube") {
            OutlinedTextField(ytQuery, { ytQuery = it }, Modifier.fillMaxWidth(), label = { Text("Search") }, singleLine = true)
            Button(enabled = ytQuery.isNotBlank(), onClick = { info = DeviceActions.youtubeSearch(ctx, ytQuery.trim()) }) { Text("YouTube par search") }
            OutlinedTextField(ytTopic, { ytTopic = it }, Modifier.fillMaxWidth(), label = { Text("Video topic / comment context") })
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = ytTopic.isNotBlank(), onClick = { vm.runTool("Give 5 catchy YouTube video titles for: $ytTopic") }) { Text("Titles") }
                Button(enabled = ytTopic.isNotBlank(), onClick = { vm.runTool("Write a YouTube video description with hashtags for: $ytTopic") }) { Text("Description") }
                Button(enabled = ytTopic.isNotBlank(), onClick = { vm.runTool("Write 3 friendly replies/comments for this YouTube context: $ytTopic") }) { Text("Comments") }
            }
            Text("Drafts upar ke Text tools card me dikhte hain. Publish/comment automatic nahi hota (YouTube Data API + OAuth chahiye — is version me shamil nahi).", style = MaterialTheme.typography.bodySmall)
        }

        Section("🎙 Voice notes") {
            if (recState != 0) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(12.dp).clip(CircleShape).background(if (recState == 1) Color.Red else Color.Gray))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        (if (recState == 1) "RECORDING " else "PAUSED ") + "%02d:%02d".format(elapsed / 60, elapsed % 60),
                        fontWeight = FontWeight.Bold, color = if (recState == 1) Color.Red else Color.Gray
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (recState == 0) {
                    Button(onClick = {
                        requestMic {
                            if (recorder.start()) { recState = 1; elapsed = 0 } else vm.fail("Recorder shuru nahi hua (mic kisi aur app ke paas ho sakta hai).")
                        }
                    }) { Text("● Record") }
                } else {
                    OutlinedButton(onClick = {
                        if (recState == 1) { recorder.pause(); recState = 2 } else { recorder.resume(); recState = 1 }
                    }) { Text(if (recState == 1) "⏸ Pause" else "▶ Resume") }
                    Button(onClick = { recorder.stop(); recState = 0; files = recorder.list() }) { Text("⏹ Stop & save") }
                }
            }
            Text("Tab badalne ya app band karne par recording save hokar ruk jati hai.", style = MaterialTheme.typography.bodySmall)
            files.forEach { f: File ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(f.name, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = {
                        player.mp?.release(); player.mp = null
                        if (playing == f.name) { playing = null } else try {
                            val mp = MediaPlayer()
                            mp.setDataSource(f.absolutePath); mp.prepare(); mp.start()
                            mp.setOnCompletionListener { playing = null }
                            player.mp = mp; playing = f.name
                        } catch (e: Exception) { vm.fail("Playback nahi ho saka: ${e.message}") }
                    }) { Text(if (playing == f.name) "⏹" else "▶") }
                    TextButton(onClick = {
                        if (playing == f.name) { player.mp?.release(); player.mp = null; playing = null }
                        f.delete(); files = recorder.list()
                    }) { Text("Delete") }
                }
            }
        }

        Section("🤖 Accessibility automation (optional)") {
            val on = remember(vm.resumeTick, PredxAccessibilityService.enabled.value) {
                PredxAccessibilityService.enabled.value || PredxAccessibilityService.isEnabledInSettings(ctx)
            }
            Text(if (on) "Status: ON ✅ (aapne khud enable ki)" else "Status: OFF — Android Settings → Accessibility me aap hi enable kar sakte hain.")
            OutlinedButton(onClick = { info = DeviceActions.settings(ctx, "android.settings.ACCESSIBILITY_SETTINGS") }) { Text("Accessibility settings kholein") }
            if (on) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { confirm = "Back button dabaya jaye?" to { info = a11yResult(PredxAccessibilityService.instance?.back()) } }) { Text("Back") }
                    Button(onClick = { confirm = "Home screen par jaye?" to { info = a11yResult(PredxAccessibilityService.instance?.home()) } }) { Text("Home") }
                }
                OutlinedTextField(clickLabel, { clickLabel = it }, Modifier.fillMaxWidth(), label = { Text("Screen par is text wale button par tap") }, singleLine = true)
                Button(enabled = clickLabel.isNotBlank(), onClick = {
                    confirm = "\"$clickLabel\" wale button par tap kiya jaye? (password/payment screens par ye istemal na karein)" to {
                        info = a11yResult(PredxAccessibilityService.instance?.clickText(clickLabel.trim()))
                    }
                }) { Text("Tap") }
            }
            Text("Ye lock screen, passwords ya Android ke permission dialogs ko bypass nahi karta.", style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(16.dp))
    }

    confirm?.let { (msg, act) ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Confirm karein") },
            text = { Text(msg) },
            confirmButton = { TextButton(onClick = { confirm = null; act() }) { Text("Haan") } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Nahi") } }
        )
    }
}

private fun a11yResult(ok: Boolean?): String = when (ok) {
    true -> "Android ne action qabool kar liya (natija screen par dekhein)."
    false -> "Action nahi ho saka (button nahi mila ya Android ne roka)."
    null -> "Accessibility service abhi connected nahi."
}
