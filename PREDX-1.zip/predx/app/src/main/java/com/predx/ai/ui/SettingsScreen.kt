package com.predx.ai.ui

import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.predx.ai.accessibility.PredxAccessibilityService
import com.predx.ai.device.DeviceActions

private val languages = listOf("English" to "en-US", "اردو (Urdu)" to "ur-PK", "Roman Urdu / Hindi" to "hi-IN")
private val personalities = listOf("Friendly", "Professional", "Funny", "Concise")
private val themes = listOf("System" to 0, "Light" to 1, "Dark" to 2)

@Composable
private fun SaveField(label: String, initial: String, secret: Boolean = false, hint: String = "", onSave: (String) -> Unit) {
    var v by remember(initial) { mutableStateOf(initial) }
    OutlinedTextField(
        v, { v = it }, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true,
        placeholder = { if (hint.isNotEmpty()) Text(hint) },
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None
    )
    TextButton(onClick = { if (!secret || v.isNotBlank()) onSave(v); if (secret) v = "" }) { Text("Save") }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val p = vm.prefs
    var lang by remember { mutableStateOf(p.language) }
    var personality by remember { mutableStateOf(p.personality) }
    var rate by remember { mutableFloatStateOf(p.speechRate) }
    var vol by remember { mutableFloatStateOf(p.volume) }
    var vision by remember { mutableStateOf(p.vision) }
    var saveHistory by remember { mutableStateOf(p.saveHistory) }
    var voiceName by remember { mutableStateOf(p.voiceName) }
    var keySaved by remember { mutableStateOf(p.apiKey.isNotBlank()) }
    var showVoices by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
        Text("Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        msg?.let { Banner(it) { msg = null } }

        Section("🧠 AI provider") {
            Text("OpenAI-compatible endpoint. Key Android Keystore se encrypted save hoti hai; kabhi dikhai nahi jati.", style = MaterialTheme.typography.bodySmall)
            SaveField("API endpoint (base URL)", p.baseUrl) { p.baseUrl = it }
            SaveField("Model", p.model) { p.model = it }
            SaveField("API key (ya proxy token)", "", secret = true, hint = if (keySaved) "Saved ✓ — nayi key daalne par badal jayegi" else "sk-…") {
                p.apiKey = it; keySaved = p.apiKey.isNotBlank()
                msg = if (keySaved) "Key encrypted save ho gayi." else "Secure storage available nahi — key save nahi hui."
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(vision, { vision = it; p.vision = it })
                Spacer(Modifier.width(8.dp))
                Text("Vision support (model images samajhta hai)", style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = { vm.testConnection() }) { Text("Connection test") }
            if (vm.testResult.isNotBlank()) Text(vm.testResult)
        }

        Section("🙂 Assistant") {
            SaveField("Assistant ka naam", p.assistantName) { p.assistantName = it }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                personalities.forEach { x ->
                    FilterChip(selected = personality == x, onClick = { personality = x; p.personality = x }, label = { Text(x) })
                }
            }
            SaveField("Extra hidayat (optional)", p.customInstructions) { p.customInstructions = it }
        }

        Section("🔊 Voice & language") {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                languages.forEach { (name, code) ->
                    FilterChip(selected = lang == code, onClick = { lang = code; p.language = code; voiceName = ""; p.voiceName = "" }, label = { Text(name) })
                }
            }
            Text("Urdu/Hindi bolne aur sunne ke liye device par us zubaan ki voice/speech data install hona zaroori hai.", style = MaterialTheme.typography.bodySmall)
            Text("Speed: ${"%.1f".format(rate)}x")
            Slider(rate, { rate = it }, valueRange = 0.5f..2f, onValueChangeFinished = { p.speechRate = rate })
            Text("Volume: ${(vol * 100).toInt()}%")
            Slider(vol, { vol = it }, valueRange = 0f..1f, onValueChangeFinished = { p.volume = vol })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { showVoices = true }) { Text("Voice: ${voiceName.ifBlank { "Default" }.takeLast(18)}") }
                Button(onClick = {
                    vm.speak(if (lang.startsWith("ur")) "السلام علیکم، میں آپ کی مدد کے لیے حاضر ہوں۔" else "Hello, I am your assistant.")
                }) { Text("Test voice") }
            }
        }

        Section("🔐 Permissions & privacy") {
            val mic = remember(vm.resumeTick) { vm.hasMic() }
            val a11y = remember(vm.resumeTick, PredxAccessibilityService.enabled.value) {
                PredxAccessibilityService.enabled.value || PredxAccessibilityService.isEnabledInSettings(ctx)
            }
            Text("Microphone: ${if (mic) "allowed ✅" else "allowed nahi"} — sirf tab record hota hai jab aap mic dabate hain.")
            Text("Accessibility: ${if (a11y) "ON ✅" else "OFF"} — optional, sirf aap enable kar sakte hain.")
            Text("Notifications: PREDX abhi koi notification nahi bhejta.", style = MaterialTheme.typography.bodySmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val i = android.content.Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + ctx.packageName))
                    i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i)
                }) { Text("App permissions") }
                OutlinedButton(onClick = { msg = DeviceActions.settings(ctx, "android.settings.ACCESSIBILITY_SETTINGS") }) { Text("Accessibility") }
                OutlinedButton(onClick = {
                    val i = android.content.Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i)
                }) { Text("Notifications") }
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(saveHistory, { saveHistory = it; p.saveHistory = it; if (!it) msg = "Nayi chats disk par save nahi hongi (purani delete karne ke liye neeche button)." })
                Spacer(Modifier.width(8.dp))
                Text("Chat history device par save karein")
            }
            Button(
                onClick = { confirmDelete = true },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = androidx.compose.ui.graphics.Color.White)
            ) { Text("Saari chat history delete") }
        }

        Section("🎨 Appearance") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                themes.forEach { (name, v) ->
                    FilterChip(selected = vm.theme == v, onClick = { vm.theme = v; p.theme = v }, label = { Text(name) })
                }
            }
        }

        Section("ℹ️ About & diagnostics") {
            val ver = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "?" }
            val online = remember(vm.resumeTick) { isOnline(ctx) }
            Text("PREDX ChatGPT AI v$ver")
            Text("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})", style = MaterialTheme.typography.bodySmall)
            Text("Internet: ${if (online) "ok" else "offline"}", style = MaterialTheme.typography.bodySmall)
            Text("Speech recognition: ${if (vm.voice.sttAvailable) "available" else "NOT available"}", style = MaterialTheme.typography.bodySmall)
            Text("Text-to-speech: ${if (vm.voice.ttsReady) "ready" else "not ready"}", style = MaterialTheme.typography.bodySmall)
            Text("API key: ${if (keySaved) "set" else "not set"} | Secure storage: ${if (p.secureAvailable) "ok" else "unavailable"}", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(6.dp))
            Text(
                "Madad: 1) Settings me endpoint, model aur key daalein. 2) \"Connection test\" dabayen. " +
                "3) Mic ke liye Home par 🎤 dabayen. Masla ho to Connection test ka message parhein.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(Modifier.height(16.dp))
    }

    if (showVoices) {
        val voices = remember(lang, showVoices) { vm.voice.voicesFor(lang) }
        AlertDialog(
            onDismissRequest = { showVoices = false },
            title = { Text("Voice chunein") },
            text = {
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    item { Text("Default", Modifier.fillMaxWidth().clickable { voiceName = ""; p.voiceName = ""; showVoices = false }.padding(12.dp)) }
                    items(voices) { n ->
                        Text(n, Modifier.fillMaxWidth().clickable { voiceName = n; p.voiceName = n; showVoices = false }.padding(12.dp))
                    }
                    if (voices.isEmpty()) item { Text("Is zubaan ki koi voice nahi mili. Android TTS settings me install karein.", Modifier.padding(12.dp)) }
                }
            },
            confirmButton = { TextButton(onClick = { showVoices = false }) { Text("Band") } }
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Saari history delete?") },
            text = { Text("Tamam chats is device se hamesha ke liye hat jayengi.") },
            confirmButton = { TextButton(onClick = { vm.clearHistory(); confirmDelete = false; msg = "History delete ho gayi." }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}
