package com.predx.ai.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.predx.ai.data.Shortcut
import com.predx.ai.device.DeviceActions

@Composable
fun AppsScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var label by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    val apps = vm.installedApps.filter { q.isBlank() || it.label.lowercase().contains(q.trim().lowercase()) }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Apps", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            IconButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "Shortcut add karein") }
        }
        vm.actionResult?.let { Banner(it) { vm.actionResult = null } }

        if (vm.shortcuts.isNotEmpty()) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text("⚡ Quick actions (Home par bhi dikhte hain)", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                vm.shortcuts.toList().forEach { s ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).clickable { vm.actionResult = DeviceActions.launchTarget(ctx, s.target) }.padding(vertical = 6.dp)) {
                            Text(s.label, fontWeight = FontWeight.Bold)
                            Text(s.target, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                        }
                        IconButton(onClick = { vm.removeShortcut(s) }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("🔍 App dhoondhein") }, singleLine = true)
        Spacer(Modifier.height(6.dp))
        if (apps.isEmpty()) {
            Text(
                if (vm.installedApps.isEmpty()) "Apps ki list load ho rahi hai ya Android ne dikhane ki ijazat nahi di."
                else "Koi app nahi mili.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        LazyColumn {
            items(apps, key = { it.pkg }) { a ->
                Row(
                    Modifier.fillMaxWidth().clickable { vm.actionResult = DeviceActions.launchApp(ctx, a.pkg) }.padding(vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(a.label, fontWeight = FontWeight.Medium)
                        Text(a.pkg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick = { vm.actionResult = DeviceActions.launchApp(ctx, a.pkg) }) { Text("Open") }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            }
        }
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Custom shortcut") },
            text = {
                Column {
                    OutlinedTextField(label, { label = it }, label = { Text("Naam") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(target, { target = it }, label = { Text("Package ya https:// link") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (label.isNotBlank() && target.isNotBlank()) vm.addShortcut(Shortcut(label.trim(), target.trim()))
                    label = ""; target = ""; showAdd = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel") } }
        )
    }
}
