package com.predx.ai.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Emerald = Color(0xFF10B981)
val EmeraldDark = Color(0xFF047857)
val Ink = Color(0xFF050807)

private val DarkScheme = darkColorScheme(
    primary = Emerald, onPrimary = Ink, secondary = Color(0xFF34D399),
    background = Ink, surface = Color(0xFF0B1210), surfaceVariant = Color(0xFF12201B),
    onBackground = Color(0xFFE6F4EE), onSurface = Color(0xFFE6F4EE), onSurfaceVariant = Color(0xFFA7C4B8),
    error = Color(0xFFFF6B6B), outline = Color(0xFF24433A)
)
private val LightScheme = lightColorScheme(
    primary = EmeraldDark, onPrimary = Color.White, secondary = Emerald,
    background = Color(0xFFF2FBF7), surface = Color.White, surfaceVariant = Color(0xFFDDF1E8),
    onBackground = Color(0xFF0B1A14), onSurface = Color(0xFF0B1A14), onSurfaceVariant = Color(0xFF3E5A4E),
    error = Color(0xFFB3261E), outline = Color(0xFF9CC4B3)
)

/** mode: 0 system, 1 light, 2 dark */
@Composable
fun PredxTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
}
