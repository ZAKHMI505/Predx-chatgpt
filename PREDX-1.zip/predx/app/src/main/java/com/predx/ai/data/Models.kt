package com.predx.ai.data

data class Message(val role: String, val content: String, val image: String? = null)
data class Conversation(val id: String, val title: String, val messages: List<Message>, val updatedAt: Long)
data class AppInfo(val label: String, val pkg: String)
data class Shortcut(val label: String, val target: String)
