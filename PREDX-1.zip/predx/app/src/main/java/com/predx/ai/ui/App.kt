package com.predx.ai.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.predx.ai.accessibility.PredxAccessibilityService

private class Holder { var cb: (() -> Unit)? = null }

@Composable
fun PredxApp(vm: MainViewModel) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var rationale by remember { mutableStateOf<(() -> Unit)?>(null) }
    val holder = remember { Holder() }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val cb = holder.cb; holder.cb = null
        if (ok) cb?.invoke() else vm.fail("Microphone permission nahi mili. Settings → Permissions se on karein.")
    }
    val requestMic: (() -> Unit) -> Unit = { cb -> if (vm.hasMic()) cb() else rationale = cb }

    val items: List<Pair<String, ImageVector>> = listOf(
        "Home" to Icons.Default.Home,
        "Chat" to Icons.Default.MailOutline,
        "Apps" to Icons.Default.List,
        "Tools" to Icons.Default.Build,
        "Settings" to Icons.Default.Settings
    )
    val bg = Brush.verticalGradient(listOf(MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.surfaceVariant))

    Box(Modifier.fillMaxSize().background(bg)) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)) {
                    items.forEachIndexed { i, (label, icon) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                if (PredxAccessibilityService.enabled.value) {
                    Banner("🤖 Accessibility automation ON — band karne ke liye Android Settings → Accessibility")
                }
                Crossfade(targetState = tab, label = "tabs") { t ->
                    when (t) {
                        0 -> HomeScreen(vm, requestMic)
                        1 -> ChatScreen(vm)
                        2 -> AppsScreen(vm)
                        3 -> ToolsScreen(vm, requestMic) { tab = 0 }
                        else -> SettingsScreen(vm)
                    }
                }
            }
        }
    }

    rationale?.let { cb ->
        AlertDialog(
            onDismissRequest = { rationale = null },
            title = { Text("Microphone ki ijazat") },
            text = {
                Text("PREDX sirf tab record karta hai jab aap mic dabate hain. Recording ka indicator screen par dikhta hai aur Stop button hamesha maujood hai. Background me kabhi record nahi hota.")
            },
            confirmButton = {
                TextButton(onClick = {
                    holder.cb = cb; rationale = null
                    launcher.launch(Manifest.permission.RECORD_AUDIO)
                }) { Text("Allow") }
            },
            dismissButton = { TextButton(onClick = { rationale = null }) { Text("Abhi nahi") } }
        )
    }
}
