package com.predx.ai.ui

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.predx.ai.ai.AiClient
import com.predx.ai.ai.AiException
import com.predx.ai.data.AppInfo
import com.predx.ai.data.ChatStore
import com.predx.ai.data.Conversation
import com.predx.ai.data.Message
import com.predx.ai.data.Prefs
import com.predx.ai.data.Shortcut
import com.predx.ai.device.Cmd
import com.predx.ai.device.CommandParser
import com.predx.ai.device.DeviceActions
import com.predx.ai.voice.VoiceController
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.UUID

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val tag = "PredxVM"
    val prefs = Prefs(app)
    private val store = ChatStore(app)
    private val ai = AiClient(prefs)
    val voice = VoiceController(app)

    // chat
    val conversations = mutableStateListOf<Conversation>()
    var currentId by mutableStateOf<String?>(null)
    var streaming by mutableStateOf(false)
    var search by mutableStateOf("")
    val current: Conversation? get() = conversations.firstOrNull { it.id == currentId }

    // home / voice
    var orb by mutableStateOf(OrbState.Idle)
    var status by mutableStateOf("Ready")
    var partial by mutableStateOf("")
    var error by mutableStateOf<String?>(null)
    var handsFree by mutableStateOf(false)
    var pending by mutableStateOf<Cmd?>(null)
    var actionResult by mutableStateOf<String?>(null)

    // misc state
    var theme by mutableIntStateOf(prefs.theme)
    var resumeTick by mutableIntStateOf(0)
    val installedApps = mutableStateListOf<AppInfo>()
    val shortcuts = mutableStateListOf<Shortcut>()
    val notes = mutableStateListOf<String>()

    // tools
    var toolOut by mutableStateOf("")
    var toolBusy by mutableStateOf(false)
    var testResult by mutableStateOf("")

    private var job: Job? = null
    private var toolJob: Job? = null
    private var speakNext = false

    init {
        conversations.addAll(store.load())
        currentId = conversations.firstOrNull()?.id
        shortcuts.addAll(prefs.shortcuts())
        notes.addAll(prefs.notes())
        loadApps()
    }

    // ---------- helpers ----------
    fun hasMic() = ContextCompat.checkSelfPermission(getApplication(), Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun systemPrompt() =
        "You are ${prefs.assistantName}, the assistant inside the PREDX ChatGPT AI Android app. " +
        "Personality: ${prefs.personality}. ${prefs.customInstructions} " +
        "Reply in the same language and script the user writes in (Urdu, Roman Urdu, English or others). " +
        "Use markdown code fences for code. You cannot operate the phone yourself; the app performs phone actions only after the user confirms."

    private fun friendly(e: Exception): String = when (e) {
        is AiException -> e.message ?: "AI error"
        is UnknownHostException, is ConnectException -> "Server tak connection nahi hua. Internet aur API endpoint check karein."
        is SocketTimeoutException -> "Server ne waqt par jawab nahi diya. Dobara try karein."
        else -> "Unexpected error: ${e.message}"
    }

    fun fail(msg: String) {
        error = msg; orb = OrbState.Error; status = "Error"
        viewModelScope.launch { delay(3000); if (orb == OrbState.Error) { orb = OrbState.Idle; status = "Ready" } }
    }

    private fun persist() { if (prefs.saveHistory) store.save(conversations.toList()) }

    private fun update(id: String, f: (Conversation) -> Conversation) {
        val i = conversations.indexOfFirst { it.id == id }
        if (i >= 0) conversations[i] = f(conversations[i])
    }

    // ---------- chats ----------
    fun newChat(): String {
        val c = Conversation(UUID.randomUUID().toString(), "New chat", emptyList(), System.currentTimeMillis())
        conversations.add(0, c); currentId = c.id; persist(); return c.id
    }
    fun select(id: String) { currentId = id }
    fun rename(id: String, title: String) { if (title.isNotBlank()) update(id) { it.copy(title = title.trim()) }; persist() }
    fun delete(id: String) {
        conversations.removeAll { it.id == id }
        if (currentId == id) currentId = conversations.firstOrNull()?.id
        persist()
    }
    fun clearHistory() { stopAll(); conversations.clear(); currentId = null; store.clear() }

    fun submit(text: String, speak: Boolean) {
        val t = text.trim()
        if (t.isEmpty()) return
        val cmd = CommandParser.parse(t, installedApps)
        if (cmd != null) {
            pending = cmd; orb = OrbState.Idle; status = "Confirm karein"
        } else {
            speakNext = speak
            send(t)
        }
    }

    fun send(text: String) {
        if (text.isBlank() || streaming) return
        val id = currentId ?: newChat()
        update(id) {
            it.copy(
                messages = it.messages + Message("user", text.trim()),
                title = if (it.messages.isEmpty()) text.trim().take(30) else it.title,
                updatedAt = System.currentTimeMillis()
            )
        }
        generate(id)
    }

    fun regenerate() {
        if (streaming) return
        val id = currentId ?: return
        update(id) { c -> if (c.messages.lastOrNull()?.role == "assistant") c.copy(messages = c.messages.dropLast(1)) else c }
        if (current?.messages?.lastOrNull()?.role == "user") generate(id)
    }

    fun editAndResend(index: Int, newText: String) {
        if (streaming || newText.isBlank()) return
        val id = currentId ?: return
        update(id) { c -> c.copy(messages = c.messages.take(index) + Message("user", newText.trim())) }
        generate(id)
    }

    private fun generate(id: String) {
        val conv = conversations.first { it.id == id }
        update(id) { it.copy(messages = it.messages + Message("assistant", "")) }
        streaming = true; error = null; orb = OrbState.Processing; status = "Soch raha hoon…"
        job = viewModelScope.launch {
            val sb = StringBuilder()
            try {
                val ctx = listOf(Message("system", systemPrompt())) + conv.messages
                ai.stream(ctx).collect { tok ->
                    sb.append(tok)
                    update(id) { c -> c.copy(messages = c.messages.dropLast(1) + Message("assistant", sb.toString())) }
                }
                if (sb.isBlank()) throw AiException("Model ne khali jawab diya.")
                if (speakNext) speak(sb.toString()) else { orb = OrbState.Idle; status = "Ready" }
            } catch (e: CancellationException) {
                orb = OrbState.Idle; status = "Ready"; throw e
            } catch (e: Exception) {
                Log.e(tag, "AI error", e)
                update(id) { c ->
                    if (c.messages.lastOrNull()?.let { it.role == "assistant" && it.content.isBlank() } == true)
                        c.copy(messages = c.messages.dropLast(1)) else c
                }
                fail(friendly(e))
            } finally {
                streaming = false; speakNext = false; persist()
            }
        }
    }

    // ---------- voice ----------
    fun startListening() {
        if (!hasMic()) { fail("Microphone permission zaroori hai."); return }
        voice.stopSpeaking(); error = null; partial = ""
        orb = OrbState.Listening; status = "Sun raha hoon… (Stop dabakar rok sakte hain)"
        voice.listen(
            prefs.language,
            onPartial = { partial = it },
            onFinal = { partial = ""; orb = OrbState.Processing; submit(it, true) },
            onFail = { msg -> partial = ""; fail(msg) }
        )
    }

    fun speak(text: String) {
        orb = OrbState.Speaking; status = "Bol raha hoon…"
        voice.speak(
            text, prefs.language, prefs.speechRate, prefs.volume, prefs.voiceName,
            onStart = {},
            onDone = {
                orb = OrbState.Idle; status = "Ready"
                if (handsFree && hasMic()) startListening()
            },
            onFail = { fail(it) }
        )
    }

    /** Pause: mic aur awaaz band, chat text mehfooz rehta hai. */
    fun pauseVoice() {
        voice.stopListening(); voice.stopSpeaking(); partial = ""
        orb = OrbState.Idle; status = "Paused"
    }

    /** Stop: mic, awaaz, AI generation aur hands-free sab band. */
    fun stopAll() {
        handsFree = false
        voice.stopListening(); voice.stopSpeaking()
        job?.cancel(); toolJob?.cancel()
        partial = ""; orb = OrbState.Idle; status = "Ready"
    }

    fun confirmPending() {
        val c = pending ?: return
        pending = null
        actionResult = DeviceActions.run(getApplication(), c)
        orb = OrbState.Idle; status = "Ready"
    }

    // ---------- apps / shortcuts / notes ----------
    fun loadApps() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { DeviceActions.installedApps(getApplication()) }
            installedApps.clear(); installedApps.addAll(list)
        }
    }
    fun addShortcut(s: Shortcut) { shortcuts.add(s); prefs.saveShortcuts(shortcuts.toList()) }
    fun removeShortcut(s: Shortcut) { shortcuts.remove(s); prefs.saveShortcuts(shortcuts.toList()) }
    fun addNote(t: String) { if (t.isNotBlank()) { notes.add(0, t.trim()); prefs.saveNotes(notes.toList()) } }
    fun removeNote(i: Int) { if (i in notes.indices) { notes.removeAt(i); prefs.saveNotes(notes.toList()) } }

    // ---------- tools ----------
    fun runTool(prompt: String, image: String? = null, onDone: ((String) -> Unit)? = null) {
        if (toolBusy) return
        if (image != null && !prefs.vision) {
            toolOut = "⚠️ Image analysis ke liye Settings me \"Vision support\" on karein (model ko images support karni chahiye)."
            return
        }
        toolBusy = true; toolOut = ""
        toolJob = viewModelScope.launch {
            val sb = StringBuilder()
            try {
                ai.stream(listOf(Message("system", systemPrompt()), Message("user", prompt, image))).collect {
                    sb.append(it); toolOut = sb.toString()
                }
                if (sb.isBlank()) toolOut = "⚠️ Model ne khali jawab diya." else onDone?.invoke(sb.toString())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(tag, "tool error", e)
                toolOut = "⚠️ " + friendly(e)
            } finally { toolBusy = false }
        }
    }

    fun testConnection() {
        testResult = "Check ho raha hai…"
        viewModelScope.launch {
            testResult = try {
                var first = ""
                ai.stream(listOf(Message("user", "Reply with the single word: OK"))).collect { if (first.length < 40) first += it }
                if (first.isBlank()) "⚠️ Khali jawab" else "✅ Server ne jawab diya: ${first.trim().take(40)}"
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { "⚠️ " + friendly(e) }
        }
    }

    override fun onCleared() { voice.shutdown() }
}
