package com.predx.ai.device

import com.predx.ai.data.AppInfo

/** Voice/text se samajhe gaye phone commands. Chalane se pehle user se confirm liya jata hai. */
sealed class Cmd {
    abstract val description: String
    data class OpenApp(val app: AppInfo) : Cmd() { override val description get() = "${app.label} app kholein" }
    data class YouTubeSearch(val query: String) : Cmd() { override val description get() = "YouTube par \"$query\" search karein" }
    data class OpenSettings(val action: String, val label: String) : Cmd() { override val description get() = "$label kholein" }
    data class OpenUrl(val url: String) : Cmd() { override val description get() = "$url kholein" }
}

object CommandParser {
    private val openWords = listOf("open ", "kholo ", "kholiye ", "launch ", "start ")
    private val suffixes = listOf(" kholo", " kholiye", " kholna", " open karo", " open kar do", " chalao", " launch karo")

    private fun appName(t: String): String? {
        openWords.firstOrNull { t.startsWith(it) }?.let { return t.removePrefix(it).trim() }
        suffixes.firstOrNull { t.endsWith(it) }?.let { return t.removeSuffix(it).trim() }
        return null
    }

    fun parse(input: String, apps: List<AppInfo>): Cmd? {
        val t = input.trim().lowercase()
        if (t.isEmpty()) return null

        if (t.contains("youtube")) {
            val m = Regex("""(?:search|find|dhoond(?:o)?|dhund(?:o)?|play)\s+(.+)""").find(t)
            if (m != null) {
                val q = m.groupValues[1]
                    .replace(Regex("""\s+(on|par|pe|per)\s+youtube$"""), "")
                    .replace("youtube", "").trim().removePrefix("for ").trim()
                if (q.isNotEmpty()) return Cmd.YouTubeSearch(q)
            }
            val m2 = Regex("""youtube\s+(?:par|pe|per|me|mein)\s+(.+?)\s+(?:search|dhoond|dhund)""").find(t)
            if (m2 != null) return Cmd.YouTubeSearch(m2.groupValues[1].trim())
        }

        val name = appName(t)?.takeIf { it.isNotEmpty() } ?: return null
        when (name.replace("-", "").replace(" ", "")) {
            "wifi", "wifisettings" -> return Cmd.OpenSettings("android.settings.WIFI_SETTINGS", "Wi-Fi settings")
            "bluetooth", "bluetoothsettings" -> return Cmd.OpenSettings("android.settings.BLUETOOTH_SETTINGS", "Bluetooth settings")
        }
        apps.firstOrNull { it.label.lowercase() == name }?.let { return Cmd.OpenApp(it) }
        apps.firstOrNull { it.label.lowercase().contains(name) }?.let { return Cmd.OpenApp(it) }
        if (name == "settings") return Cmd.OpenSettings("android.settings.SETTINGS", "Settings")
        if (name == "youtube") return Cmd.OpenUrl("https://www.youtube.com")
        if (name == "browser" || name == "google") return Cmd.OpenUrl("https://www.google.com")
        return null
    }
}
