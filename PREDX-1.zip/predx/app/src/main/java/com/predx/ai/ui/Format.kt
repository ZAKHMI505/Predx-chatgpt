package com.predx.ai.ui

data class Segment(val text: String, val isCode: Boolean)

/** ``` fences ke hisaab se text aur code alag karta hai (streaming me adhoora fence bhi code mana jata hai). */
fun splitCode(input: String): List<Segment> =
    input.split("```").mapIndexedNotNull { i, p ->
        if (i % 2 == 1) Segment(p.substringAfter('\n', p).trimEnd(), true)
        else if (p.isBlank()) null
        else Segment(p.trim(), false)
    }
