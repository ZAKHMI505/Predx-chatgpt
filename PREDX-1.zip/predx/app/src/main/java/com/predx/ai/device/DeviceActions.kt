package com.predx.ai.device

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import com.predx.ai.data.AppInfo

/**
 * Sirf official Android intents. startActivity() ka matlab hai "Android ne request qabool ki" —
 * ye guarantee nahi ke kaam hua, isliye messages me "kamyab" kabhi nahi likha jata.
 */
object DeviceActions {
    private const val SENT = "Android ko request bhej di gayi (natija Android confirm nahi karta)."

    fun installedApps(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun start(ctx: Context, intent: Intent): String = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        SENT
    } catch (e: ActivityNotFoundException) {
        "Is kaam ke liye koi app nahi mili."
    } catch (e: SecurityException) {
        "Android ne is action ki ijazat nahi di."
    }

    fun launchApp(ctx: Context, pkg: String): String {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return "Is app ka launch intent nahi mila ($pkg)."
        return start(ctx, i)
    }

    fun launchTarget(ctx: Context, target: String): String =
        if (target.startsWith("http://") || target.startsWith("https://")) openUrl(ctx, target) else launchApp(ctx, target)

    fun openUrl(ctx: Context, url: String): String {
        if (!(url.startsWith("https://") || url.startsWith("http://"))) return "Sirf http/https links supported hain."
        return start(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    fun youtubeSearch(ctx: Context, q: String) =
        openUrl(ctx, "https://www.youtube.com/results?search_query=" + Uri.encode(q))

    /** User message khud review karke WhatsApp me Send dabata hai. Auto-send nahi. */
    fun whatsApp(ctx: Context, phone: String, text: String): String {
        val digits = phone.filter { it.isDigit() }
        val url = (if (digits.isBlank()) "https://wa.me/" else "https://wa.me/$digits") + "?text=" + Uri.encode(text)
        return openUrl(ctx, url)
    }

    fun settings(ctx: Context, action: String) = start(ctx, Intent(action))

    /** Calendar ka event-editor khulta hai; user Save dabaye to hi reminder banta hai. */
    fun reminder(ctx: Context, title: String, inMinutes: Int): String {
        val begin = System.currentTimeMillis() + inMinutes * 60_000L
        val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + 15 * 60_000L)
        return start(ctx, i)
    }

    /** Clipboard sirf tab padhi jati hai jab user ne button dabaya. */
    fun readClipboard(ctx: Context): String? {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString()
    }

    fun copy(ctx: Context, text: String) {
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("PREDX", text))
    }

    fun run(ctx: Context, c: Cmd): String = when (c) {
        is Cmd.OpenApp -> launchApp(ctx, c.app.pkg)
        is Cmd.YouTubeSearch -> youtubeSearch(ctx, c.query)
        is Cmd.OpenSettings -> settings(ctx, c.action)
        is Cmd.OpenUrl -> openUrl(ctx, c.url)
    }
}
