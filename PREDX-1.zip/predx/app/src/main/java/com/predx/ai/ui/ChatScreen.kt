package com.predx.ai.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.predx.ai.data.Conversation
import com.predx.ai.data.Message
import com.predx.ai.device.DeviceActions

fun boldText(s: String): AnnotatedString = buildAnnotatedString {
    s.split("**").forEachIndexed { i, p ->
        if (i % 2 == 1) withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(p) } else append(p)
    }
}

@Composable
fun MessageText(text: String) {
    SelectionContainer {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            splitCode(text).forEach { seg ->
                if (seg.isCode) {
                    Box(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.Black.copy(alpha = 0.6f))
                            .horizontalScroll(rememberScrollState()).padding(10.dp)
                    ) { Text(seg.text, fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color(0xFFB7F7DC)) }
                } else Text(boldText(seg.text))
            }
        }
    }
}

@Composable
fun ChatScreen(vm: MainViewModel) {
    var showList by remember { mutableStateOf(false) }
    if (showList) ConversationList(vm) { showList = false } else ChatView(vm) { showList = true }
}

@Composable
private fun ChatView(vm: MainViewModel, openList: () -> Unit) {
    var input by remember { mutableStateOf("") }
    var renameOpen by remember { mutableStateOf(false) }
    var renameText by remember { mutableStateOf("") }
    var editIdx by remember { mutableStateOf<Int?>(null) }
    var editText by remember { mutableStateOf("") }
    val msgs = vm.current?.messages.orEmpty()
    val listState = rememberLazyListState()

    LaunchedEffect(msgs.size, msgs.lastOrNull()?.content?.length) {
        if (msgs.isNotEmpty()) listState.scrollToItem(msgs.lastIndex)
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = openList) { Icon(Icons.Default.Menu, "Chats") }
            Text(
                vm.current?.title ?: "PREDX Chat", Modifier.weight(1f), maxLines = 1,
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold
            )
            IconButton(onClick = { renameText = vm.current?.title.orEmpty(); renameOpen = true }, enabled = vm.current != null) {
                Icon(Icons.Default.Create, "Rename")
            }
            IconButton(onClick = { vm.newChat() }) { Icon(Icons.Default.Add, "New chat") }
        }

        if (msgs.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("💬 Nayi baat shuru karein.\nUrdu, Roman Urdu ya English — jo marzi.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.weight(1f), state = listState, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(msgs.size) { i ->
                    Bubble(msgs[i], i == msgs.lastIndex, vm) { editIdx = i; editText = msgs[i].content }
                }
            }
        }

        vm.error?.let { err ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { Banner(err, error = true) }
                TextButton(onClick = { vm.error = null; vm.regenerate() }) { Text("Retry") }
            }
        }

        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Message likhein…") }, maxLines = 4, shape = RoundedCornerShape(16.dp)
            )
            if (vm.streaming) {
                TextButton(onClick = { vm.stopAll() }) { Text("⏹ Stop") }
            } else {
                IconButton(onClick = { vm.send(input); input = "" }, enabled = input.isNotBlank()) {
                    Icon(Icons.Default.Send, "Send")
                }
            }
        }
    }

    if (renameOpen) {
        AlertDialog(
            onDismissRequest = { renameOpen = false },
            title = { Text("Chat ka naam") },
            text = { OutlinedTextField(renameText, { renameText = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = { vm.currentId?.let { vm.rename(it, renameText) }; renameOpen = false }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renameOpen = false }) { Text("Cancel") } }
        )
    }
    editIdx?.let { idx ->
        AlertDialog(
            onDismissRequest = { editIdx = null },
            title = { Text("Message edit karein") },
            text = { OutlinedTextField(editText, { editText = it }, minLines = 2) },
            confirmButton = {
                TextButton(onClick = { vm.editAndResend(idx, editText); editIdx = null }) { Text("Dobara bhejein") }
            },
            dismissButton = { TextButton(onClick = { editIdx = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun Bubble(m: Message, isLast: Boolean, vm: MainViewModel, onEdit: () -> Unit) {
    val ctx = LocalContext.current
    val mine = m.role == "user"
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
        Box(
            Modifier.widthIn(max = 330.dp).clip(RoundedCornerShape(18.dp))
                .background(if (mine) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f) else MaterialTheme.colorScheme.surfaceVariant)
                .padding(12.dp)
        ) {
            if (m.content.isEmpty()) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
            else MessageText(m.content)
        }
        Row {
            if (m.content.isNotEmpty()) {
                TextButton(onClick = {
                    DeviceActions.copy(ctx, m.content)
                    Toast.makeText(ctx, "Copy ho gaya", Toast.LENGTH_SHORT).show()
                }) { Text("Copy") }
            }
            if (mine && !vm.streaming) TextButton(onClick = onEdit) { Text("Edit") }
            if (!mine && m.content.isNotEmpty()) TextButton(onClick = { vm.speak(m.content) }) { Text("🔊") }
            if (!mine && isLast && !vm.streaming && m.content.isNotEmpty()) {
                TextButton(onClick = { vm.regenerate() }) { Text("Regenerate") }
            }
        }
    }
}

@Composable
private fun ConversationList(vm: MainViewModel, onClose: () -> Unit) {
    var del by remember { mutableStateOf<Conversation?>(null) }
    val q = vm.search.trim().lowercase()
    val shown = vm.conversations.filter { c ->
        q.isEmpty() || c.title.lowercase().contains(q) || c.messages.any { it.content.lowercase().contains(q) }
    }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onClose) { Text("← Wapas") }
            Spacer(Modifier.weight(1f))
            Button(onClick = { vm.newChat(); onClose() }) { Text("+ New chat") }
        }
        OutlinedTextField(
            value = vm.search, onValueChange = { vm.search = it }, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("🔍 Purani chats search karein") }, singleLine = true
        )
        Spacer(Modifier.height(8.dp))
        if (shown.isEmpty()) Text("Koi chat nahi mili.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn {
            items(shown, key = { it.id }) { c ->
                GlassCard(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { vm.select(c.id); onClose() }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.title, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text("${c.messages.size} messages", style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { del = c }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                }
            }
        }
    }
    del?.let { c ->
        AlertDialog(
            onDismissRequest = { del = null },
            title = { Text("Chat delete karein?") },
            text = { Text("\"${c.title}\" hamesha ke liye hat jayegi.") },
            confirmButton = { TextButton(onClick = { vm.delete(c.id); del = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("Cancel") } }
        )
    }
}
