package com.predx.ai.ai

import com.predx.ai.data.Message
import com.predx.ai.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AiException(message: String) : Exception(message)

/** OpenAI-compatible /chat/completions client (streaming SSE). Endpoint, model aur key Settings se aate hain. */
class AiClient(private val prefs: Prefs) {

    fun stream(messages: List<Message>): Flow<String> = flow {
        val key = prefs.apiKey
        if (key.isBlank()) throw AiException("API key set nahi hai. Settings → AI provider me key daalein.")
        val base = prefs.baseUrl.trim().trimEnd('/')
        if (!(base.startsWith("https://") || base.startsWith("http://")))
            throw AiException("API endpoint http:// ya https:// se shuru hona chahiye.")

        val msgs = JSONArray()
        messages.forEach { m ->
            val o = JSONObject().put("role", m.role)
            if (m.image != null) {
                o.put("content", JSONArray()
                    .put(JSONObject().put("type", "text").put("text", m.content))
                    .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", m.image))))
            } else o.put("content", m.content)
            msgs.put(o)
        }
        val body = JSONObject().put("model", prefs.model).put("stream", true).put("messages", msgs).toString()

        val conn = URL("$base/chat/completions").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 90_000
            conn.doOutput = true
            conn.setRequestProperty("Authorization", "Bearer $key")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Accept", "text/event-stream")
            conn.outputStream.use { it.write(body.toByteArray()) }

            val code = conn.responseCode
            if (code !in 200..299) {
                val err = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                val hint = when (code) {
                    401, 403 -> " (API key ghalat ya ijazat nahi)"
                    404 -> " (endpoint ya model ka naam check karein)"
                    429 -> " (rate limit / quota)"
                    else -> ""
                }
                throw AiException("API error $code$hint: ${err.take(300)}")
            }

            if (conn.contentType.orEmpty().contains("json")) {
                // Server ne streaming nahi ki: poora jawab ek saath
                val txt = conn.inputStream.bufferedReader().use { it.readText() }
                val c = JSONObject(txt).optJSONArray("choices")?.optJSONObject(0)
                    ?.optJSONObject("message")?.optString("content", "").orEmpty()
                if (c.isNotEmpty()) emit(c)
            } else {
                conn.inputStream.bufferedReader().use { r ->
                    while (true) {
                        val line = r.readLine() ?: break
                        if (!line.startsWith("data:")) continue
                        val data = line.removePrefix("data:").trim()
                        if (data == "[DONE]") break
                        val delta = try {
                            JSONObject(data).optJSONArray("choices")?.optJSONObject(0)
                                ?.optJSONObject("delta")?.optString("content", "").orEmpty()
                        } catch (e: Exception) { "" }
                        if (delta.isNotEmpty()) emit(delta)
                    }
                }
            }
        } finally {
            conn.disconnect()
        }
    }.flowOn(Dispatchers.IO)
}
