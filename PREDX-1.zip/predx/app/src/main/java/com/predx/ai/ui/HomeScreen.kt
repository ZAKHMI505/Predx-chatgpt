package com.predx.ai.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.predx.ai.device.DeviceActions

@Composable
fun HomeScreen(vm: MainViewModel, requestMic: (() -> Unit) -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    val online = remember(vm.resumeTick) { isOnline(ctx) }
    val last = vm.current?.messages?.lastOrNull { it.role == "assistant" }?.content.orEmpty()
    val listening = vm.orb == OrbState.Listening

    val quick = buildList<Pair<String, () -> Unit>> {
        add("▶ YouTube" to { vm.actionResult = DeviceActions.openUrl(ctx, "https://www.youtube.com") })
        add("🌐 Browser" to { vm.actionResult = DeviceActions.openUrl(ctx, "https://www.google.com") })
        add("📶 Wi‑Fi" to { vm.actionResult = DeviceActions.settings(ctx, "android.settings.WIFI_SETTINGS") })
        add("🗣 Urdu me baat" to { vm.submit("Mujhse Urdu me baat karo", false) })
        add("💡 Idea do" to { vm.submit("Mujhe aaj ke liye ek chhota productivity tip do", false) })
        vm.shortcuts.forEach { s -> add(s.label to { vm.actionResult = DeviceActions.launchTarget(ctx, s.target) }) }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("PREDX ChatGPT AI", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        if (!online) Banner("📴 Offline — AI jawab ke liye internet chahiye.", error = true)
        Spacer(Modifier.height(8.dp))

        Box(Modifier.clip(CircleShape).clickable { if (listening) vm.stopAll() else requestMic { vm.startListening() } }) {
            Orb(vm.orb, orbSize = 230.dp)
        }
        Text(vm.status, style = MaterialTheme.typography.titleMedium)
        if (vm.partial.isNotBlank()) {
            Text("“${vm.partial}”", fontStyle = FontStyle.Italic, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (listening) {
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(Color.Red))
                Spacer(Modifier.width(8.dp))
                Text("MIC ON — recording ho rahi hai", color = Color.Red, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { requestMic { vm.startListening() } }, enabled = !listening) { Text("🎤 Start") }
            OutlinedButton(onClick = { vm.pauseVoice() }) { Text("⏸ Pause") }
            Button(
                onClick = { vm.stopAll() },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = Color.White)
            ) { Text("⏹ Stop") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = vm.handsFree, onCheckedChange = { vm.handsFree = it })
            Spacer(Modifier.width(8.dp))
            Text("Hands-free (jawab ke baad dobara sunna)", style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(8.dp))

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text, onValueChange = { text = it }, modifier = Modifier.weight(1f),
                placeholder = { Text("Yahan likhein… (e.g. open YouTube)") },
                maxLines = 3, shape = RoundedCornerShape(16.dp)
            )
            IconButton(
                onClick = { vm.submit(text, false); text = "" },
                enabled = text.isNotBlank() && !vm.streaming
            ) { Icon(Icons.Default.Send, contentDescription = "Send") }
        }
        Spacer(Modifier.height(8.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(quick) { (label, act) -> AssistChip(onClick = act, label = { Text(label) }) }
        }

        vm.error?.let { Banner(it, error = true) { vm.error = null } }
        vm.actionResult?.let { Banner(it) { vm.actionResult = null } }

        if (last.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Aakhri jawab", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                SelectionContainer { Text(last.take(700)) }
                Row {
                    TextButton(onClick = {
                        DeviceActions.copy(ctx, last)
                        Toast.makeText(ctx, "Copy ho gaya", Toast.LENGTH_SHORT).show()
                    }) { Text("Copy") }
                    TextButton(onClick = { vm.speak(last) }) { Text("🔊 Sunao") }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }

    vm.pending?.let { cmd ->
        AlertDialog(
            onDismissRequest = { vm.pending = null },
            title = { Text("Confirm karein") },
            text = { Text(cmd.description) },
            confirmButton = { TextButton(onClick = { vm.confirmPending() }) { Text("Haan, karo") } },
            dismissButton = { TextButton(onClick = { vm.pending = null }) { Text("Nahi") } }
        )
    }
}
