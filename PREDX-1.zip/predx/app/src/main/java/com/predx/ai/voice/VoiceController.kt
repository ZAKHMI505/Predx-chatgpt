package com.predx.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Android SpeechRecognizer (STT) + TextToSpeech (TTS). Mic sirf listen() ke dauran on hota hai. */
class VoiceController(context: Context) {
    private val ctx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    @Volatile var ttsReady = false
        private set

    init {
        tts = TextToSpeech(ctx) { ttsReady = it == TextToSpeech.SUCCESS }
    }

    val sttAvailable: Boolean get() = SpeechRecognizer.isRecognitionAvailable(ctx)

    fun voicesFor(lang: String): List<String> {
        if (!ttsReady) return emptyList()
        val l = Locale.forLanguageTag(lang).language
        return try {
            tts?.voices?.filter { it.locale.language == l }?.map { it.name }?.sorted() ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }

    fun listen(lang: String, onPartial: (String) -> Unit, onFinal: (String) -> Unit, onFail: (String) -> Unit) {
        main.post {
            if (!sttAvailable) {
                onFail("Is device par speech recognition service maujood nahi (Google app / Speech Services install karein).")
                return@post
            }
            releaseNow()
            val r = SpeechRecognizer.createSpeechRecognizer(ctx)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onPartialResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onPartial)
                }
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    releaseNow()
                    if (t.isBlank()) onFail("Kuch sunai nahi diya. Dobara try karein.") else onFinal(t)
                }
                override fun onError(error: Int) {
                    releaseNow()
                    onFail(sttMessage(error))
                }
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            }
            r.startListening(i)
        }
    }

    private fun sttMessage(code: Int) = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Aawaz samajh nahi aayi. Dobara bolein."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service ke liye internet masla hai."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission nahi hai."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy hai, thori der baad try karein."
        else -> "Speech recognition error (code $code)."
    }

    private fun releaseNow() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
    }

    fun stopListening() { main.post { releaseNow() } }

    fun speak(
        text: String, lang: String, rate: Float, volume: Float, voiceName: String,
        onStart: () -> Unit, onDone: () -> Unit, onFail: (String) -> Unit
    ) {
        val t = tts
        if (t == null || !ttsReady) { onFail("Text-to-speech engine tayyar nahi."); return }
        val loc = Locale.forLanguageTag(lang)
        val res = t.setLanguage(loc)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            onFail("${loc.displayName} ki voice install nahi. Android Settings → Text-to-speech me voice data download karein.")
            return
        }
        if (voiceName.isNotBlank()) {
            t.voices?.firstOrNull { it.name == voiceName && it.locale.language == loc.language }?.let { t.voice = it }
        }
        t.setSpeechRate(rate)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { main.post { onStart() } }
            override fun onDone(utteranceId: String?) { main.post { onDone() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { main.post { onFail("Awaaz play karne me masla aaya.") } }
        })
        val clean = text.replace(Regex("```[\\s\\S]*?```"), " code block ").replace(Regex("[*#`_]"), "").take(3500)
        val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceIn(0f, 1f)) }
        t.speak(clean, TextToSpeech.QUEUE_FLUSH, params, "predx")
    }

    fun stopSpeaking() { tts?.stop() }

    fun shutdown() {
        main.post { releaseNow() }
        tts?.stop(); tts?.shutdown(); tts = null
    }
}
