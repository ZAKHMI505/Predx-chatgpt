# Termux guide

## A) Backend proxy (optional, verified: unit tests pass)
```
pkg update -y && pkg upgrade -y
pkg install -y python git unzip
termux-setup-storage                       # storage permission allow karein
cp ~/storage/downloads/PREDX.zip ~ && cd ~ && unzip PREDX.zip && cd predx/backend
cp .env.example .env && nano .env          # PREDX_TOKEN aur UPSTREAM_API_KEY bharein
python3 -c "import secrets; print(secrets.token_urlsafe(32))"   # token banane ke liye
python3 -m unittest -v                     # tests
python3 server.py                          # start (Ctrl+C se stop)
```
Test (doosri Termux session me):
```
curl http://127.0.0.1:8000/health
```
App me: endpoint `http://127.0.0.1:8000/v1`, key = PREDX_TOKEN. (Plain http sirf 127.0.0.1/localhost/10.0.2.2 ke liye allowed hai.)
Termux Android ne band kar diya to proxy bhi band — `termux-wake-lock` use karein.

## B) APK banana
### Route 1 (recommended): GitHub Actions — README dekhein.

### Route 2 (experimental, mene Termux par test NAHI kiya): on-device Gradle build
Android ka official aapt2 x86 hai aur aarch64 Termux par nahi chalta; Termux ka apna `aapt2` package use hota hai.
```
pkg install -y openjdk-17 gradle wget unzip aapt2     # agar aapt2 na mile: pkg search aapt
mkdir -p ~/android-sdk/cmdline-tools && cd ~/android-sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-*.zip && mv cmdline-tools latest
export ANDROID_HOME=$HOME/android-sdk
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin
yes | sdkmanager --licenses
sdkmanager "platforms;android-34" "build-tools;34.0.0"
cd ~/predx
echo "sdk.dir=$ANDROID_HOME" > local.properties
sed -i 's|^# android.aapt2FromMavenOverride=.*|android.aapt2FromMavenOverride='$PREFIX'/bin/aapt2|' gradle.properties
gradle :app:assembleDebug --no-daemon
```
APK: `app/build/outputs/apk/debug/app-debug.apk` → `cp` karke `~/storage/downloads/`.

### Troubleshooting
- `aapt2 ... Syntax error / cannot execute`: aapt2 override line (gradle.properties) uncomment nahi hui.
- `Out of memory`: `org.gradle.jvmargs=-Xmx1024m`, `--no-daemon`, baqi apps band karein.
- `SDK location not found`: `local.properties` me `sdk.dir`.
- `Could not resolve ...`: internet check; pehli build me kaafi download hota hai.
- Compile error: poora error text copy karke bhejein.
- App me "API error 401": key/token ghalat. "404": endpoint ya model naam. "Connection nahi hua": proxy chal raha hai? endpoint `/v1` tak.
